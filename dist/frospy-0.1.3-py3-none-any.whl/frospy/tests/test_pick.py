from frospy.core.pick import Pick
p = Pick(fw1=1, fw2=2)

assert p.fw1 == 1
assert p.fw2 == 2
