from .splittingfunc import SplittingFunc, calc_cst_indices
from .set import Set
