from frospy.core.spectrum.spectrum import Spectrum
from frospy.core.splittingfunc.splittingfunc import SplittingFunc
